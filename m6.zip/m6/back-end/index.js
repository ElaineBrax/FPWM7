const express = require("express");
const app = express();
const cors = require("cors");

app.use(cors({ origin: "http://localhost:5173", optionsSuccessStatus: 200 }));

app.get("/api/contacts", function (req, res) {
  return res.status(200).send([
    { username: "kanna04", password: "123" },
    { username: "luna99", password: "123" },
    { username: "merryl49", password: "123" },
  ]);
});

const port = 3000;
app.listen(port, function () {
  console.log(`listening on port ${port}`);
});