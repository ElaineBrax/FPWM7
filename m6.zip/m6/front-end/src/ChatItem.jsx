export default function ChatItem({ chat, sender }) {
    return (
      <>
        <div
          style={{ float: sender ? "right" : "left", border: "1px solid black" }}
        >
          {chat.message} <br />
          {chat.sentAt}
        </div>
        <div style={{ clear: "both", marginBottom: "10px" }}></div>
      </>
    );
}