import { useDispatch, useSelector } from "react-redux";
import { useRef, useState } from "react";
import { doLogout } from "./app/accountSlice";
import ChatItem from "./ChatItem";

export default function ChatForm() {
  const currentUser = useSelector(
    (state) => state.account.accounts[state.account.loggedIn]
  );
  const accounts = useSelector((state) => state.account.accounts);
  const [chatWith, setChatWith] = useState("");
  const chatTxt = useRef(null);
  const dispatch = useDispatch();
  function logout(){
    dispatch(doLogout())
  }
  return (
    <>
      <h3>Welcome {currentUser.username}!</h3>
      <button onClick={logout}>Logout</button>
      <hr />
      <div style={{ display: "flex", width: "100%" }}>
        <div style={{ flex: 1 }}>
          <h5>Chat with:</h5>
          <table>
            <thead>
              <tr>
                <th>username</th>
                <th>action</th>
              </tr>
            </thead>
            <tbody>
              {accounts
                .filter((a) => a.username != currentUser.username)
                .map((a) => (
                  <tr key={a.username}>
                    <td>{a.username}</td>
                    <td>
                      <button onClick={() => setChatWith(a.username)}>
                        Chat
                      </button>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
        {chatWith ? (
          <div style={{ flex: 1 }}>
            <h4>Chatting with {chatWith}</h4>
            <input type="text" ref={chatTxt} />
            <button>Send</button>
            <div style={{ clear: "both", marginBottom: "10px" }}></div>
            <ChatItem></ChatItem>
          </div>
        ) : (
          ""
        )}
      </div>
    </>
  );
}