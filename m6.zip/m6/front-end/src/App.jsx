import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import ChatForm from "./ChatForm";
import LoginForm from "./LoginForm";
import RegisterForm from "./RegisterForm";
import axios from "axios";
import { accountsloaded } from "./app/accountSlice";

function App() {
  const page = useSelector((state) => state.app.page);
  const loggedIn = useSelector((state) => state.account.loggedIn);
  const dispatch = useDispatch();
  useEffect(() => {
    axios.get("http://localhost:3000/api/contacts").then(function(response){
      dispatch(accountsloaded(response.data));
      console.log(response.data);
    })
  }, [])
  if (loggedIn != -1) {
    return <ChatForm></ChatForm>
  }
  else{
    if(page === "register"){
      return <RegisterForm></RegisterForm>
    }
    else{
      return <LoginForm></LoginForm>
    }
  }
}

export default App;
