import { createSlice } from "@reduxjs/toolkit";
export const accountSlice = createSlice({
    name:"account",
    initialState:{
        accounts:[],
        loggedIn: -1,
        status:{
            error: false,
            message: "",
        }
    },
    reducers:{
        accountsloaded: (state, action) => {
            state.accounts = action.payload;
            state.status = {
                error: false,
                message: ""
            }
        },
        doRegister: (state, action) => {
            const {username, password} = action.payload;
            const idx = state.accounts.findIndex(
                (a) => a.username == username
            );
            if (username == "" || password == "" || idx>-1) {
                state.status = {
                    error: true,
                    message: "username/password is invalid"
                }
            }
            else{
                state.accounts.push({
                    username: username,
                    password: password
                });
                state.status = {
                    error: false,
                    message: "Register successful"
                }
            }
        },
        doLogout: (state, action) => {
            state.loggedIn = -1
        }, 
        doLogin: (state, action) => {
            const {username, password} = action.payload;
            const idx = state.accounts.findIndex(
                (a) => a.username == username && a.password == password
            );
            if (idx > -1) {
                state.loggedIn = idx;
                state.status = {
                    error: false,
                    message: "login successful"
                }
            }
            else{
                state.status = {
                    error: true,
                    message: "username/password not found"
                }
            }
        },
        clearError: (state) => {
            state.status = {
                error: false,
                message: ""
            }
        }
    }
});

export const {accountsloaded, clearError, doLogin, doRegister, doLogout} = accountSlice.actions;
export default accountSlice.reducer;