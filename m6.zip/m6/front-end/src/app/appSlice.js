import { createSlice, current } from "@reduxjs/toolkit";
export const appSlice = createSlice({
  name: "app",
  initialState: {
    page: "login",
  },
  reducers: {
    toLoginPage: (state) => {
    //   console.log(current(state));
      state.page = "login";
    },
    toRegisterPage: (state) => {
      state.page = "register";
    },
  },
});
export const { toLoginPage, toRegisterPage } = appSlice.actions;
export default appSlice.reducer;
