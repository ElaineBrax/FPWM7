import { createSlice } from "@reduxjs/toolkit";
// isi chats.json akan dishare di codeshare
import { chats } from "./chats.json";
export const chatSlice = createSlice({
  name: "chat",
  initialState: chats,
  reducers: {
    sendChat: (state, action) => {
      state.push(action.payload);
    },
  },
});
export const { sendChat } = chatSlice.actions;
export default chatSlice.reducer;