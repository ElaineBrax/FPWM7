import { configureStore } from "@reduxjs/toolkit";
import accountSlice from "./accountSlice";
import appReducer from "./appSlice";

export default configureStore({
  reducer: {
    app: appReducer,
    account: accountSlice
  },
});
