import { useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { doRegister } from "./app/accountSlice";
import { toLoginPage } from "./app/appSlice";

export default function RegisterForm() {
  const dispatch = useDispatch();
  const usernameTxt = useRef(null);
  const passwordTxt = useRef(null);
  console.log(toLoginPage());
  const status = useSelector((state) => state.account.status)
  function register(){
    dispatch(doRegister({username: usernameTxt.current.value, password: passwordTxt.current.value}))
  }
  return (
    <>
      <button onClick={() => dispatch(toLoginPage())}>Login</button>
      <hr />
      username: <input type="text" ref={usernameTxt} />
      <br />
      password: <input type="text" ref={passwordTxt} />
      <br />
      <button onClick={register}>Register</button>
      <br />
      <span>{status.message}</span>
    </>
  );
}
