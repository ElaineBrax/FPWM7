import { useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { doLogin } from "./app/accountSlice";
import { toRegisterPage } from "./app/appSlice";
export default function LoginForm() {
  const dispatch = useDispatch();
  const usernameTxt = useRef(null);
  const passwordTxt = useRef(null);
  const status = useSelector((state) => state.account.status)
  function login(){
    dispatch(doLogin({username: usernameTxt.current.value, password: passwordTxt.current.value}))
  }
  return (
    <>
      <button onClick={() => dispatch(toRegisterPage())}>Register</button>
      <hr />
      username: <input type="text" ref={usernameTxt} />
      <br />
      password: <input type="text" ref={passwordTxt} />
      <br />
      <button onClick={login}>Login</button>
      <br />
      <span>{status.message}</span>
    </>
  );
}
